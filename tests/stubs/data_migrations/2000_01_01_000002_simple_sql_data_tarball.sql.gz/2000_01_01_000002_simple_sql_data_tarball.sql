INSERT INTO foo_table VALUES (1, 'tarball-ed', 'data');
